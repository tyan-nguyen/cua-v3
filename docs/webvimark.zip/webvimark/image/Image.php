<?php
namespace webvimark\image;

use webvimark\image\Kohana\Kohana_Image;

abstract class Image extends Kohana_Image {}
?>