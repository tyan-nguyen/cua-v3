<?php

use webvimark\modules\UserManagement\UserManagementModule;
use yii\helpers\Html;

/**
 * @var yii\web\View $this
 * @var webvimark\modules\UserManagement\models\User $user
 */

$this->title = UserManagementModule::t('front', 'E-mail confirmed');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container login-container">

<div class="row" style="padding-left:0px; padding-right:0px;">
 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-sign-in-alt"></i> <b>XÁC NHẬN TÀI KHOẢN</b></div>
        </div>
</div>

       <div class="row">

	<div class="col-md-12 alert alert-success text-center">
		<?= UserManagementModule::t('front', 'E-mail confirmed') ?> - <b><?= $user->email ?></b>

		<?php if ( isset($_GET['returnUrl']) ): ?>
			<br/>
			<br/>
			<b><?= Html::a(UserManagementModule::t('front', 'Continue'), $_GET['returnUrl'], ['class'=>'btn btn-lg btn-success btn-block']) ?></b>
		<?php endif; ?>
	</div>

</div>
</div>
