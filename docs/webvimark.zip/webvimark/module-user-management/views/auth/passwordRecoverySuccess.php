<?php

use webvimark\modules\UserManagement\UserManagementModule;

/**
 * @var yii\web\View $this
 */

$this->title = UserManagementModule::t('front', 'Password recovery');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container login-container">

<div class="row" style="padding-left:0px; padding-right:0px;">
 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-sign-in-alt"></i> <b>QUÊN MẬT KHẨU</b></div>
        </div>
</div>

       <div class="row">
	<div class="col-md-12 text-center" style="margin-top: 20px;"><h3>GỬI YÊU CẦU THÀNH CÔNG!</h3></div>
	<div class="col-md-12 alert alert-success text-center">
		<?= UserManagementModule::t('front', 'Check your E-mail for further instructions') ?>
	</div>

</div>
</div>
