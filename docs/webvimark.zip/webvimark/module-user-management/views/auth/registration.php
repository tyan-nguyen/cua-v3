<?php

use webvimark\modules\UserManagement\UserManagementModule;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;
use yii\helpers\Html;
use yii\helpers\Url;
use app\models\SSetting;

$setting = SSetting::findOne(1);
/**
 * @var yii\web\View $this
 * @var webvimark\modules\UserManagement\models\forms\RegistrationForm $model
 */

$this->title = UserManagementModule::t('front', 'Đăng ký tài khoản');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="row" style="padding-left:0px; padding-right:0px;">

 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-sign-in-alt"></i> <b><?= $this->title ?></b></div>
        </div>
</div>

 <div class="col-md-12">

 <div class="row">

        <div class="col-md-6 login-form">
          <h3>ĐĂNG KÝ TÀI KHOẢN</h3>
          <hr/>



	<?php $form = ActiveForm::begin([
		'id'=>'user',
		//'layout'=>'horizontal',
		'validateOnBlur'=>true,
	]); ?>

	<?= $form->field($model, 'username')->textInput(['maxlength' => 50, 'autocomplete'=>'off', 'autofocus'=>true])->label('Email (*)') ?>

	<?php /* $form->field($model, 'email')->textInput(['maxlength' => 250, 'autocomplete'=>'off']) */ ?>

	<?= $form->field($model, 'password')->passwordInput(['maxlength' => 255, 'autocomplete'=>'off'])->label('Password (*)')?>

	<?= $form->field($model, 'repeat_password')->passwordInput(['maxlength' => 255, 'autocomplete'=>'off'])->label('Password repeat (*)')?>

	<?= $form->field($model, 'name')->textInput(['maxlength' => 255, 'autocomplete'=>'off'])->label('Your Name (*)')?>

	<?= $form->field($model, 'address')->textInput(['maxlength' => 255, 'autocomplete'=>'off']) ?>
	<?= $form->field($model, 'phone')->textInput(['maxlength' => 255, 'autocomplete'=>'off']) ?>

	<?= $form->field($model, 'captcha')->widget(Captcha::className(), [
		'template' => '<div class="row"><div class="col-sm-3">{image}</div> <div class="col-sm-5" style="margin-left:10px;">{input}</div></div>',
		'captchaAction'=>['/user-management/auth/captcha']
	]) ?>

	<div class="row">
		<div class="col-md-12">

			<?= Html::submitButton(
				'<span class="glyphicon glyphicon-ok"></span> ' . UserManagementModule::t('front', 'Đăng ký'),
				['class' => 'btn btn-warning btn-lg btn-block']
			) ?>
		</div>
	</div>

	<?php ActiveForm::end(); ?>



</div>

<div class="col-md-6 ads">
          <?= $setting->content_quyen_loi_thanh_vien ?>

          <?= $setting->content_huong_dan_dang_ky ?>


          <h2 style="color:#0088cc;">Đã có tài khoản?</h2>
          <ul class="login-list">
          		<li><a href="<?= Yii::getAlias('@web') ?>/user-management/auth/login">Đăng nhập</a></li>
          		<li><a href="<?= Yii::getAlias('@web') ?>/user-management/auth/password-recovery">Quên mật khẩu?</a></li>
          </ul>

        </div>

</div>
</div>
