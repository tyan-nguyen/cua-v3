<?php
use webvimark\modules\UserManagement\UserManagementModule;
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
?>

<h1>ĐĂNG NHẬP</h1>

<?php 
$form = ActiveForm::begin([
	'id'=>'login-form',
    'options'=>['autocomplete'=>'off', 'class'=>'login-form'],
	'validateOnBlur'=>false,
	'fieldConfig' => [
		//'template'=>"{input}\n{error}",
		'template'=>"{input}",
	],
                
]) ?>

		<?= $form->errorSummary($model); ?>

		<?= $form->field($model, 'username')
			->textInput(['placeholder'=>'Email', 'autocomplete'=>'off']) ?>

		<?= $form->field($model, 'password')
			->passwordInput(['placeholder'=>$model->getAttributeLabel('password'), 'autocomplete'=>'off']) ?>

		<?= Html::submitButton(
			UserManagementModule::t('front', '<i class="fa fa-unlock-alt" aria-hidden="true"></i> ĐĂNG NHẬP'),
			['class' => 'btn btn-warning btn-lg', 'style'=>'margin-top:10px;']
		) ?>

<?php ActiveForm::end() ?>