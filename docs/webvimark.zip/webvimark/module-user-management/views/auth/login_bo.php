<?php
/**
 * @var $this yii\web\View
 * @var $model webvimark\modules\UserManagement\models\forms\LoginForm
 */

use webvimark\modules\UserManagement\components\GhostHtml;
use webvimark\modules\UserManagement\UserManagementModule;
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;

//$setting = SSetting::findOne(1);
?>

<style>
.error-summary{
	background: #f7e2c0;
	text-align:left;
	padding:10px;
	margin-bottom:20px;
}
.error-summary ul li{
	list-style-type: circle;
}
h1{
	color:#f7a41e;
	font-size:20px;
}
</style>

 <nav aria-label="breadcrumb">
	<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= Yii::getAlias('@web') ?>">Trang chủ</a></li>
        <li class="breadcrumb-item active" aria-current="page">
			Đăng nhập
        </li>
     </ol>
</nav>

<div class="row">
<div class="col-lg-12 col-md-12 col-xs-12">
<div class="news-content">


<section id="story" class="grid-100 mobile-grid-100" style="text-align: center">
<div class="grid-100 mobile-grid-100 SectionHead">
	<h1 style="margin-top:0px;color:#0a977c">ĐĂNG NHẬP</h1>
</div>
<div class="grid-100 mobile-grid-100 album-search" >
          <!-- <form>
            <div class="form-group">
              <input type="text" class="form-control" name="username" placeholder="Username">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="password" placeholder="Password">
            </div>
            <div class="form-group">
              <button type="button" class="btn btn-primary btn-lg btn-block">ĐĂNG NHẬP</button>
            </div>
            <div class="form-group forget-password">
                <a href="#">Quên mật khẩu</a>
            </div>
          </form> -->


        <?php $form = ActiveForm::begin([
						'id'      => 'login-form',
						'options'=>['autocomplete'=>'off'],
						'validateOnBlur'=>false,
						'fieldConfig' => [
							//'template'=>"{input}\n{error}",
							'template'=>"{input}",
						],
					]) ?>

					<?= $form->errorSummary($model); ?>

				<?= $form->field($model, 'username')
					->textInput(['placeholder'=>'Email', 'autocomplete'=>'off']) ?>

				<?= $form->field($model, 'password')
					->passwordInput(['placeholder'=>$model->getAttributeLabel('password'), 'autocomplete'=>'off']) ?>

				<?= Html::submitButton(
					UserManagementModule::t('front', '<i class="fa fa-unlock-alt" aria-hidden="true"></i> ĐĂNG NHẬP'),
					['class' => 'btn btn-success btn-lg', 'style'=>'margin-top:10px;']
				) ?>

		<?php ActiveForm::end() ?>

</div>

</section>

</div>
</div>
</div>