<?php

use webvimark\modules\UserManagement\UserManagementModule;
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\models\SSetting;

//$setting = SSetting::findOne(1);
/**
 * @var yii\web\View $this
 * @var webvimark\modules\UserManagement\models\forms\ChangeOwnPasswordForm $model
 */

$this->title = UserManagementModule::t('back', 'Thay đổi mật khẩu');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="container">

<div class="row" style="padding-left:0px; padding-right:0px;">
<!-- <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-key"></i> ĐỔI MẬT KHẨU</div>
        </div>-->
</div>

       <div class="row">



			<?php if ( Yii::$app->session->hasFlash('success') ): ?>
				<div class="col-md-12 alert alert-success text-center">
					<?= Yii::$app->session->getFlash('success') ?>
				</div>
			<?php endif; ?>

<div class="col-md-6" style="border:0px;">
<h1 class="text-center"><?= $this->title ?></h1>
		<hr/>
				<?php $form = ActiveForm::begin([
					'id'=>'user',
					//'layout'=>'horizontal',
					'validateOnBlur'=>false,
				]); ?>

				<?php if ( $model->scenario != 'restoreViaEmail' ): ?>
					<?= $form->field($model, 'current_password')->passwordInput(['maxlength' => 255, 'autocomplete'=>'off']) ?>

				<?php endif; ?>

				<?= $form->field($model, 'password')->passwordInput(['maxlength' => 255, 'autocomplete'=>'off']) ?>

				<?= $form->field($model, 'repeat_password')->passwordInput(['maxlength' => 255, 'autocomplete'=>'off']) ?>


				<div class="row">
					<div class="col-md-12">
						<?= Html::submitButton(
							'<span class="glyphicon glyphicon-ok"></span> ' . UserManagementModule::t('back', 'Xác nhận thay đổi'),
							['class' => 'btn btn-warning btn-lg btn-block']
						) ?>
					</div>
				</div>

				<?php ActiveForm::end(); ?>
</div>
<div class="col-md-6 ads">
        	<?php // $setting->content_huong_dan_doi_mat_khau ?>

        </div>
</div>
</div>
