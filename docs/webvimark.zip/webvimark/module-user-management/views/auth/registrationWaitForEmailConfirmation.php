<?php

use webvimark\modules\UserManagement\UserManagementModule;

/**
 * @var yii\web\View $this
 * @var webvimark\modules\UserManagement\models\User $user
 */

$this->title = UserManagementModule::t('front', 'Registration - confirm your e-mail');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container login-container">

<div class="row" style="padding-left:0px; padding-right:0px;">
 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-sign-in-alt"></i> <b>ĐĂNG KÝ TÀI KHOẢN</b></div>
        </div>
</div>

       <div class="row">
	<div class="col-md-12 text-center" style="margin-top: 20px;"><h3>BƯỚC TIẾP THEO: XÁC NHẬN TÀI KHOẢN</h3></div>
	<div class="col-md-12 alert alert-success text-center">
		<?= UserManagementModule::t('front', 'Check your e-mail {email} for instructions to activate account', [
			'email'=>'<b>'. $user->email .'</b>'
		]) ?>
	</div>

</div>
</div>
