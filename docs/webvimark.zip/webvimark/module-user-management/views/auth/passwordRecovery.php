<?php

use webvimark\modules\UserManagement\UserManagementModule;
use yii\bootstrap\ActiveForm;
use yii\captcha\Captcha;
use yii\helpers\Html;
use app\models\SSetting;

$setting = SSetting::findOne(1);

/**
 * @var yii\web\View $this
 * @var webvimark\modules\UserManagement\models\forms\PasswordRecoveryForm $model
 */

$this->title = UserManagementModule::t('front', 'Password recovery');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="container login-container">

<div class="row" style="padding-left:0px; padding-right:0px;">
 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-key"></i> <b>QUÊN MẬT KHẨU</b></div>
        </div>
</div>
<div class="row">
	<div class="col-md-6 login-form">

		<h2 class="text-center"><?= $this->title ?></h2>
		<hr/>

	<?php if ( Yii::$app->session->hasFlash('error') ): ?>
		<div class="alert-alert-warning text-center">
			<?= Yii::$app->session->getFlash('error') ?>
		</div>
	<?php endif; ?>

	<?php $form = ActiveForm::begin([
		'id'=>'user',
		//'layout'=>'horizontal',
		'validateOnBlur'=>false,
	]); ?>

	<?= $form->field($model, 'email')->textInput(['maxlength' => 255, 'autofocus'=>true]) ?>

	<?= $form->field($model, 'captcha')->widget(Captcha::className(), [
		'template' => '<div class="row"><div class="col-sm-2">{image}</div><div class="col-sm-3">{input}</div></div>',
		'captchaAction'=>['/user-management/auth/captcha']
	]) ?>

	<div class="row">
		<div class="col-md-12">
			<?= Html::submitButton(
				'<span class="glyphicon glyphicon-ok"></span> ' . UserManagementModule::t('front', 'Recover'),
				['class' => 'btn btn-warning btn-lg btn-block']
			) ?>
		</div>
	</div>

	<div class="row registration-block">
					<div class="col-sm-12" style="text-align: center; margin-top:5px;">
						<?php /* GhostHtml::a(
							UserManagementModule::t('front', "Đăng ký"),
							['/user-management/auth/registration']
						)*/ ?>

						Đã nhớ mật khẩu? <?= Html::a("Login",
							['/user-management/auth/login']
						) ?>
					</div>
				</div>

	<?php ActiveForm::end(); ?>

</div>

        <div class="col-md-6 ads">
        	<?= $setting->content_huong_dan_khoi_phuc_mat_khau ?>

          	<?= $setting->content_quyen_loi_thanh_vien ?>

          <a href="<?= Yii::getAlias('@web') ?>/user-management/auth/registration" class="btn btn-lg btn-success btn-block">ĐĂNG KÝ NGAY</a>

        </div>
   </div>
   </div>
