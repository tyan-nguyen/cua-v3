<?php

use webvimark\modules\UserManagement\UserManagementModule;
use yii\helpers\Url;
use yii\helpers\Html;
/**
 * @var yii\web\View $this
 */

$this->title = UserManagementModule::t('back', 'Thay đổi mật khẩu');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="container login-container">

<!--
<div class="row" style="padding-left:0px; padding-right:0px;">
 <div class="btn-group btn-breadcrumb breadcrumb-default list-heading">
            <div class="btn btn-info"><i class="fas fa-sign-in-alt"></i> <b>ĐỔI MẬT KHẨU</b></div>
        </div>
</div>-->

       <div class="row">

	<div class="col-md-12 alert alert-success text-center">
		<?= UserManagementModule::t('back', 'Mật khẩu đã được đổi thành công!') ?>
	</div>

	<!-- <div class="col-md-12 text-center" style="margin-bottom:20px;">
		<?= Html::a('Về trang ACCOUNT', Yii::getAlias('@web') . '/user-management/user', ['class' => 'btn btn-primary btn-lg']) ?>
	</div> -->

</div>
</div>
