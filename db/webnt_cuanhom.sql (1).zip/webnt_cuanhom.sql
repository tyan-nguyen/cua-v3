-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 11, 2023 at 02:36 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webnt_cuanhom`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', 1, 1556454369),
('bientapvien', 1, 1570155479),
('bientapvien', 6, 1664291263),
('Default', 1, 1556454369),
('Default', 6, 1664291263),
('duyettin', 1, 1570155479),
('thongketruycap', 6, 1664291263);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/admin/*', 3, NULL, NULL, NULL, 1555604426, 1555604426, NULL),
('/admin/catelogies/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/default/*', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/default/index', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/links/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/del-folder-not-used', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/thong-ke-truy-cap/*', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/bulk-delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/create', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/index', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/update', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/view', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/page/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/about-us', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/captcha', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/contact', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/*', 3, NULL, NULL, NULL, 1555604424, 1555604424, NULL),
('/site/cat', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/index', 3, NULL, NULL, NULL, 1555604425, 1555604425, NULL),
('/site/news', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/newsletter', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/not-found', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/search', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1426062189, 1426062189, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('bientapvien', 1, 'Biên tập viên', NULL, NULL, 1570120917, 1570120917, NULL),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('cauhinh', 2, 'Cấu hình', NULL, NULL, 1570156160, 1570156160, 'userCommonPermissions'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1426062189, 1426062189, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1426062188, 1426062188, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('dangtin', 2, 'Đăng tin', NULL, NULL, 1570156034, 1570156034, 'userCommonPermissions'),
('Default', 1, 'Default', NULL, NULL, 1555604497, 1555604497, NULL),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('duyettin', 1, 'Duyệt tin', NULL, NULL, 1570120962, 1570120962, NULL),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('per_dashboard', 2, 'Access Dashboard', NULL, NULL, 1664291118, 1664291118, 'userManagement'),
('permission_thongketruycap', 2, 'Thống kê truy cập', NULL, NULL, 1586086798, 1586086798, 'userCommonPermissions'),
('qltaikhoan', 2, 'Quản lý tài khoản', NULL, NULL, 1570156229, 1570156229, 'userManagement'),
('thongketruycap', 1, 'Thống kê truy cập', NULL, NULL, 1586086766, 1586086766, NULL),
('truycaptrangadmin', 2, 'Truy cập trang admin', NULL, NULL, 1570121444, 1570121444, 'userCommonPermissions'),
('user-default', 2, 'user-default', NULL, NULL, 1555604419, 1555604419, 'userCommonPermissions'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1426062189, 1426062189, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('per_dashboard', '/admin/*'),
('per_dashboard', '/admin/catelogies/*'),
('per_dashboard', '/admin/default/*'),
('truycaptrangadmin', '/admin/default/*'),
('user-default', '/admin/default/*'),
('user-default', '/admin/default/index'),
('per_dashboard', '/admin/links/*'),
('per_dashboard', '/admin/news/*'),
('per_dashboard', '/admin/settings/*'),
('per_dashboard', '/admin/socials/*'),
('per_dashboard', '/admin/thong-ke-truy-cap/*'),
('permission_thongketruycap', '/admin/thong-ke-truy-cap/*'),
('user-default', '/site/*'),
('qltaikhoan', '/user-management/*'),
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('viewVisitLog', '/user-management/user-visit-log/grid-page-size'),
('viewVisitLog', '/user-management/user-visit-log/index'),
('viewVisitLog', '/user-management/user-visit-log/view'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'cauhinh'),
('Admin', 'changeOwnPassword'),
('bientapvien', 'changeOwnPassword'),
('duyettin', 'changeOwnPassword'),
('user-default', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'dangtin'),
('bientapvien', 'dangtin'),
('duyettin', 'dangtin'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('bientapvien', 'per_dashboard'),
('thongketruycap', 'permission_thongketruycap'),
('Admin', 'qltaikhoan'),
('Default', 'thongketruycap'),
('Admin', 'truycaptrangadmin'),
('bientapvien', 'truycaptrangadmin'),
('Default', 'truycaptrangadmin'),
('duyettin', 'truycaptrangadmin'),
('Admin', 'user-default'),
('bientapvien', 'user-default'),
('Default', 'user-default'),
('duyettin', 'user-default'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1426062189, 1426062189),
('userManagement', 'User management', 1426062189, 1426062189);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `open_new_tab` tinyint(1) NOT NULL,
  `priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name`, `link`, `open_new_tab`, `priority`) VALUES
(1, 'Terms & Conditions', '/page/terms', 0, 2),
(2, 'Privacy Policy', '/page/privacy', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1480859869),
('m140209_132017_init', 1480859873),
('m140403_174025_create_account_table', 1480859874),
('m140504_113157_update_tables', 1480859876),
('m140504_130429_create_token_table', 1480859876),
('m140506_102106_rbac_init', 1480867652),
('m140830_171933_fix_ip_field', 1480859877),
('m140830_172703_change_account_table_name', 1480859877),
('m141222_110026_update_ip_field', 1480859877),
('m141222_135246_alter_username_length', 1480859877),
('m150425_012013_init', 1570158165),
('m150425_082737_redirects', 1570158165),
('m150614_103145_update_social_account_table', 1480859878),
('m150623_212711_fix_username_notnull', 1480859878),
('m151218_234654_add_timezone_to_profile', 1480859878);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imgcover` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `catelogies` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` text COLLATE utf8_unicode_ci,
  `summary` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `just_for_this_site` tinyint(1) DEFAULT NULL,
  `site_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_link` text COLLATE utf8_unicode_ci,
  `date_updated` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `post_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_keywords` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_static` tinyint(1) DEFAULT NULL,
  `is_product` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_catelogies` (`catelogies`)
) ENGINE=InnoDB AUTO_INCREMENT=1904 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `code`, `imgcover`, `catelogies`, `title`, `slug`, `summary`, `content`, `date_created`, `just_for_this_site`, `site_id`, `site_link`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `post_status`, `tags`, `site_keywords`, `is_static`, `is_product`) VALUES
(1886, '20231006-201531-b7sl', '', 'tin-tuc', 'Đại lý cửa nhôm Xingfa chính hãng tại Trà Vinh 2', 'dai-ly-cua-nhom-xingfa-chinh-hang-tai-tra-vinh', 'Cửa nhôm Xingfa nhập khẩu là thuật ngữ dùng để chỉ các dòng cửa được làm từ nhôm Xingfa nhập khẩu kết hợp cùng kính, hệ thống gioăng kép EDPM và phụ kiện đi kèm. Nhôm Xingfa còn có tên gọi khác là nhôm hệ Xingfa. Đây là dòng nhôm thanh định hình của Công ty TNHH Nhôm Xingfa Quảng Đông- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.', '<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p class=\"float-end\" style=\"text-align: right;\"><strong>DNTN SX-TM Nguyễn Tr&igrave;nh</strong></p>', '2023-10-06 20:17:21', 0, '', '', '2023-10-10 10:00:25', 1, '', '', 'PUBLISH', 'nhom-xingfa', '', 0, 0),
(1887, '20231006-205023-by5J', '', 'tin-tuc;bao-gia', 'Đại lý cửa nhôm Xingfa chính hãng tại Trà Vinh 1', 'dai-ly-cua-nhom-xingfa-chinh-hang-tai-tra-vinh-2', 'Cửa nhôm Xingfa nhập khẩu là thuật ngữ dùng để chỉ các dòng cửa được làm từ nhôm Xingfa nhập khẩu kết hợp cùng kính, hệ thống gioăng kép EDPM và phụ kiện đi kèm. Nhôm Xingfa còn có tên gọi khác là nhôm hệ Xingfa. Đây là dòng nhôm thanh định hình của Công ty TNHH Nhôm Xingfa Quảng Đông- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.', '<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p class=\"float-end\" style=\"text-align: right;\"><strong>DNTN SX-TM Nguyễn Tr&igrave;nh</strong></p>', '2023-10-06 20:52:26', NULL, NULL, NULL, '2023-10-10 09:59:57', 1, '', '', 'PUBLISH', 'nhom-xingfa', NULL, 0, 0),
(1888, '20231006-205239-7Tdh', '', 'tin-tuc;dai-ly', 'Đại lý 1', 'dai-ly-cua-nhom-xingfa-chinh-hang-tai-tra-vinh-3', 'Cửa nhôm Xingfa nhập khẩu là thuật ngữ dùng để chỉ các dòng cửa được làm từ nhôm Xingfa nhập khẩu kết hợp cùng kính, hệ thống gioăng kép EDPM và phụ kiện đi kèm. Nhôm Xingfa còn có tên gọi khác là nhôm hệ Xingfa. Đây là dòng nhôm thanh định hình của Công ty TNHH Nhôm Xingfa Quảng Đông- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.', '<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p class=\"float-end\" style=\"text-align: right;\"><strong>DNTN SX-TM Nguyễn Tr&igrave;nh</strong></p>', '2023-10-06 20:53:44', NULL, NULL, NULL, '2023-10-10 09:59:41', 1, '', '', 'PUBLISH', 'nhom-xingfa', NULL, 0, 0),
(1889, '20231009-103032-hazN', '', 'tin-tuc', 'Đại lý cửa nhôm Xingfa chính hãng tại Trà Vinh 4', 'dai-ly-cua-nhom-xingfa-chinh-hang-tai-tra-vinh-4', 'Cửa nhôm Xingfa nhập khẩu là thuật ngữ dùng để chỉ các dòng cửa được làm từ nhôm Xingfa nhập khẩu kết hợp cùng kính, hệ thống gioăng kép EDPM và phụ kiện đi kèm. Nhôm Xingfa còn có tên gọi khác là nhôm hệ Xingfa. Đây là dòng nhôm thanh định hình của Công ty TNHH Nhôm Xingfa Quảng Đông- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.', '<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<h2>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; g&igrave;?</h2>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p><img class=\"img-fluid\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/images/single-image2.jpg\" alt=\"post-image\" /></p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p>Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất. Cửa nh&ocirc;m Xingfa nhập khẩu l&agrave; thuật ngữ d&ugrave;ng để chỉ c&aacute;c d&ograve;ng cửa được l&agrave;m từ nh&ocirc;m Xingfa nhập khẩu kết hợp c&ugrave;ng k&iacute;nh, hệ thống gioăng k&eacute;p EDPM v&agrave; phụ kiện đi k&egrave;m. Nh&ocirc;m Xingfa c&ograve;n c&oacute; t&ecirc;n gọi kh&aacute;c l&agrave; nh&ocirc;m hệ Xingfa. Đ&acirc;y l&agrave; d&ograve;ng nh&ocirc;m thanh định h&igrave;nh của C&ocirc;ng ty TNHH Nh&ocirc;m Xingfa Quảng Đ&ocirc;ng- Trung Quốc (GUANGDONG XINGFA ALUMINIUM CO., LTD) sản xuất.</p>\r\n<p class=\"float-end\" style=\"text-align: right;\"><strong>DNTN SX-TM Nguyễn Tr&igrave;nh</strong></p>', '2023-10-09 10:30:54', NULL, NULL, NULL, '2023-10-10 10:00:02', 1, '', '', 'PUBLISH', '', NULL, 0, 0),
(1892, '20231009-144049-BzN8', NULL, '0', 'Tại sao là chúng tôi?', 'tai-sao-la-chung-toi', '', '<p>fasfdasf</p>', '2023-10-09 14:40:53', NULL, NULL, NULL, '2023-10-10 09:12:13', 1, '', '', 'PUBLISH', '', NULL, 1, 0),
(1893, '20231010-092035-yQ5B', NULL, '0', 'Quy trình lắp đặt', 'quy-trinh-lap-dat', '', '<h2>Quy tr&igrave;nh lắp đặt cửa đi 2 c&aacute;nh</h2>\r\n<ul>\r\n<li>Bước 1: Tiếp nhận th&ocirc;ng tin. Nhận th&ocirc;ng tin từ kh&aacute;ch h&agrave;ng, l&ecirc;n lịch hẹn.</li>\r\n<li>Bước 2: Khảo s&aacute;t (khảo s&aacute;t thực tế, xem bản vẽ trao đổi, tư vấn điểm mạnh điểm yếu, để kh&aacute;ch h&agrave;ng hiểu).</li>\r\n<li>Bước 3: Thiết kế (thiết kế bằng bảng vẽ chuy&ecirc;n ng&agrave;nh để kh&aacute;ch h&agrave;ng xem v&agrave; điều chỉnh đi đến thống nhất).</li>\r\n<li>Bước 4: B&aacute;o gi&aacute;. Lập dự to&aacute;n b&aacute;o gi&aacute; cửa đi 2 c&aacute;nh nh&ocirc;m xingfa để kh&aacute;ch biết chi ph&iacute; dự tr&ugrave;.</li>\r\n<li>Bước 5: K&yacute; hợp đồng. Sau khi đi đến thống nhất bản vẽ, th&ocirc;ng số, b&aacute;o gi&aacute; v&agrave; c&aacute;c điều khoản sẽ được k&yacute; hợp đồng.</li>\r\n<li>Bước 6: Sản xuất. Tiến h&agrave;nh sản xuất theo quy tr&igrave;nh chuẩn đ&atilde; định sẵn trước đ&oacute;.</li>\r\n<li>Bước 7: Lắp đặt. Nhận mặt bằng v&agrave; tiến h&agrave;nh thực hiện quy tr&igrave;nh lắp đặt cửa đi 2 c&aacute;nh nh&ocirc;m Xingfa.</li>\r\n<li>Bước 8: Vệ sinh v&agrave; b&agrave;n giao. Kiểm tra lại lần cuối v&agrave; tiến h&agrave;nh vệ sinh b&agrave;n giao c&ocirc;ng tr&igrave;nh.</li>\r\n<li>Bước 9: Chăm s&oacute;c bảo tr&igrave;. Theo đ&oacute;, kể từ ng&agrave;y nghiệm thu 6 th&aacute;ng sẽ tiến h&agrave;nh kiểm tra bảo tr&igrave; cửa 1 lần.</li>\r\n</ul>', '2023-10-10 09:20:45', NULL, NULL, NULL, '2023-10-10 09:23:13', 1, '', '', 'PUBLISH', '', NULL, 1, 0),
(1894, '20231010-092119-BwES', NULL, '0', 'Chính sách vận chuyển', 'chinh-sach-van-chuyen', '', '<h2>Ch&iacute;nh s&aacute;ch vận chuyển</h2>\r\n<h3>1. Phương thức mua h&agrave;ng:</h3>\r\n<p>Qu&yacute; kh&aacute;ch c&oacute; thể đến trực tiếp địa chỉ showroom xingfa glass để xem v&agrave; mua h&agrave;ng. Qu&yacute; kh&aacute;ch đặt mua trực tiếp tr&ecirc;n website đơn h&agrave;ng sẽ được ch&uacute;ng t&ocirc;i xử l&yacute; gọi lại ngay cho bạn khi nhận được. Q&uacute;y kh&aacute;ch c&oacute; thể đặt mua th&ocirc;ng qua HOTLINE: 0294.384.0058 v&agrave; thanh to&aacute;n bằng phương thức chuyển khoản hoặc thanh to&aacute;n bằng tiền mặt trực tiếp tại cửa h&agrave;ng.</p>\r\n<h3>2. Thanh To&aacute;n:</h3>\r\n<ul>\r\n<li>Thanh to&aacute;n trực tiếp tại cửa h&agrave;ng.</li>\r\n<li>Thanh to&aacute;n th&ocirc;ng qua chuyển khoản ng&acirc;n h&agrave;ng.</li>\r\n<li>Đối với một số sản phẩm l&agrave;m theo y&ecirc;u cầu qu&yacute; kh&aacute;ch vui l&ograve;ng đặt cọc trước một số tiền quy định theo hợp đồng k&yacute; kết, sau khi nhận h&agrave;ng Qu&yacute; kh&aacute;ch thanh to&aacute;n nốt số tiền c&ograve;n lại.</li>\r\n</ul>\r\n<h3>3. Vận chuyển</h3>\r\n<p>DNTN SX-TM Nguyễn Tr&igrave;nh sẽ giao h&agrave;ng tận nơi tr&ecirc;n phạm vi tỉnh Tr&agrave; Vinh v&agrave; c&aacute;c tỉnh l&acirc;n cận. Ph&iacute; vận chuyển: Miễn ph&iacute; khu vực tỉnh Tr&agrave; Vinh. C&aacute;c khu vực kh&aacute;c t&ugrave;y theo b&aacute;n k&iacute;nh sẽ theo thỏa thuận. Hoặc theo Hợp đồng k&yacute; kết thực tế.</p>\r\n<p>Mọi vấn đề ph&aacute;t sinh khi mua h&agrave;ng, thanh to&aacute;n v&agrave; vận chuyển qu&yacute; kh&aacute;ch vui l&ograve;ng li&ecirc;n lạc với ch&uacute;ng t&ocirc;i</p>\r\n<h2>Ch&iacute;nh s&aacute;ch bảo h&agrave;nh</h2>\r\n<h3>1. Thời hạn bảo h&agrave;nh:</h3>\r\n<p>Thời điểm bảo h&agrave;nh bắt đầu được t&iacute;nh từ ng&agrave;y b&agrave;n giao hết thời hạn sau:</p>\r\n<ul>\r\n<li>05 - 10 năm cho cửa nh&ocirc;m xingfa nhập khẩu Tem đỏ Quảng Đ&ocirc;ng</li>\r\n<li>02 năm cho phụ kiện keo, 03 năm cho phụ kiện cửa nh&ocirc;m</li>\r\n</ul>\r\n<h3>2. Phạm vi bảo h&agrave;nh:</h3>\r\n<p>Tr&aacute;ch nhiệm thay thế miễn ph&iacute; sản phẩm kh&ocirc;ng đạt y&ecirc;u cầu ngoại trừ những lỗi của b&ecirc;n B tại khoản 3.</p>\r\n<h3>3. Phạm vi kh&ocirc;ng bảo h&agrave;nh gồm những điều sau:</h3>\r\n<p>&ndash; Sản phẩm bị biến dạng do để c&aacute;c nguồn nhiệt độ m&ocirc;i trường tr&ecirc;n 600C gần sản phẩm uPVC hoặc sản phẩm bị tiếp x&uacute;c với c&aacute;c loại axit v&agrave; ho&aacute; chất đặc biệt l&agrave;m ảnh hưởng v&agrave; biến đổi đặc t&iacute;nh sản phẩm của thanh uPVC.</p>\r\n<p>&ndash; Sản phẩm uPVC, hộp k&iacute;nh v&agrave; phụ kiện kim kh&iacute; bị hỏng h&oacute;c do lỗi của ngư&shy;ời sử dụng hoặc cố &yacute; g&acirc;y hỏng, sử dụng c&aacute;c ho&aacute; chất kh&ocirc;ng đ&uacute;ng với hướng dẫn của nh&agrave; sản xuất, vận h&agrave;nh sai quy tắc hướng dẫn, người sử dụng tự &yacute; chỉnh sửa lấy. Cửa được lắp tại c&aacute;c m&ocirc;i trường ăn m&ograve;n kim loại nhưng sử dụng phụ kiện kim kh&iacute; kh&ocirc;ng th&iacute;ch hợp mặc d&ugrave; đ&atilde; được DNTN SX-TM Nguyễn Tr&igrave;nh khuyến c&aacute;o kh&ocirc;ng n&ecirc;n sử dụng.</p>\r\n<p>Tự &yacute; thay đổi, lắp đặt th&ecirc;m v&agrave;o hoặc bớt đi nguy&ecirc;n bản của sản phẩm v&agrave; điều kiện đ&atilde; lắp đặt.</p>\r\n<h3>4. Hỗ trợ kh&aacute;ch h&agrave;ng</h3>\r\n<p>DNTN SX-TM Nguyễn Tr&igrave;nh sẽ hỗ trợ sửa chữa, thay thế sản phẩm bị hỏng h&oacute;c, hư hại (kh&ocirc;ng thuộc phạm vi từ chối tr&aacute;ch nhiệm bảo h&agrave;nh). To&agrave;n bộ c&aacute;c chi ph&iacute; sửa chữa thay thế như nh&acirc;n c&ocirc;ng, chi ph&iacute; sản xuất, vật tư đ&oacute;ng g&oacute;i, vận chuyển, đi lại, ăn ở của c&aacute;n bộ kỹ thuật kh&aacute;ch h&agrave;ng phải thanh to&aacute;n theo b&aacute;o gi&aacute; sửa chữa (nếu c&oacute;).</p>', '2023-10-10 09:21:25', NULL, NULL, NULL, '2023-10-10 10:00:35', 1, '', '', 'PUBLISH', '', NULL, 1, 0),
(1895, '20231010-092139-HQw8', NULL, '0', 'Chính sách thanh toán', 'chinh-sach-thanh-toan', '', '', '2023-10-10 09:21:45', NULL, NULL, NULL, '2023-10-10 09:22:48', 1, '', '', 'PUBLISH', '', NULL, 1, 0),
(1896, '20231010-092155-labM', NULL, '0', 'Yêu cầu bảo hành', 'yeu-cau-bao-hanh', '', '', '2023-10-10 09:22:01', NULL, NULL, NULL, '2023-10-10 09:22:44', 1, '', '', 'PUBLISH', '', NULL, 1, 0),
(1898, '20231010-094440-pthW', '', 'bao-gia', 'Báo giá cửa nhôm tháng 10/2023', 'bao-gia-cua-nhom-thang-10-2023', '', '', '2023-10-10 09:44:56', NULL, NULL, NULL, '2023-10-10 10:00:28', 1, '', '', 'PUBLISH', '', NULL, 0, 0),
(1900, '20231010-151634-Gz0I', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/product-item1.png', 'he-cua-nhom;he-cua-di', 'SP 12', 'sp-1', '<p>Khi nhắc đến một bộ cửa ch&iacute;nh gồm 2 c&aacute;nh đẹp nhất định kh&ocirc;ng thể bỏ qua 2 yếu tố đ&oacute; l&agrave;: phong thủy v&agrave; thẩm mỹ. Trong đ&oacute;, k&iacute;ch thước cửa ch&iacute;nh 2 c&aacute;nh theo phong thủy được coi l&agrave; yếu tố đặc biệt quan trọng, n&oacute; sẽ mang lại t&agrave;i lộc, may mắn v&agrave; sự thịnh thượng cho gia chủ.</p>\r\n<div class=\"product-action mt-4\">\r\n<div class=\"detail-list mt-3\">\r\n<ul>\r\n<li>Mẫu nh&ocirc;m: Thanh profile nh&ocirc;m Xingfa hệ 55</li>\r\n<li>Độ d&agrave;y: Khu&ocirc;n bao khung v&agrave; c&aacute;nh cửa d&agrave;y 2.0(mm)</li>\r\n<li>K&iacute;nh cường lực d&agrave;y 8 (mm)</li>\r\n<li>Keo Apollo ch&iacute;nh h&atilde;ng</li>\r\n<li>Ke vĩnh cữu kh&iacute;t tuyệt đối, tăng cứng d&agrave;y 4,0 (mm)</li>\r\n<li>Gioăng k&eacute;p</li>\r\n<li>Ốc v&iacute;t Inox si&ecirc;u cứng &amp; chống han rỉ</li>\r\n<li>C&ocirc;ng nghệ &eacute;p g&oacute;c bằng d&agrave;n m&aacute;y &eacute;p 3 lưỡi dao k&iacute;n kh&iacute;t tuyệt đối</li>\r\n<li>Thời gian bảo h&agrave;nh:&nbsp;<strong>5-10 năm</strong></li>\r\n</ul>\r\n</div>\r\n</div>', '<h2>Chi tiết sản phẩm</h2>\r\n<p>Cửa đi 2 c&aacute;nh nh&ocirc;m Xingfa l&agrave; một trong những loại cửa bền bỉ, được c&aacute;c gia đ&igrave;nh Việt ưu ti&ecirc;n lựa chọn hiện nay. Kh&ocirc;ng chỉ sở hữu vẻ đẹp sang trọng, thời thượng m&agrave; cửa loại n&agrave;y c&ograve;n mang &yacute; nghĩa phong thủy s&acirc;u sắc.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/20231010-151634-Gz0I/product-item-more1.png\" alt=\"product-item-more1\" /></p>\r\n<p>Với d&ograve;ng cửa đi 2 c&aacute;nh nh&ocirc;m xingfa tại DNTN SX-TM Nguyễn Tr&igrave;nh được thiết kế t&iacute;nh tế, sang trọng gi&uacute;p kh&ocirc;ng gian ngồi nh&agrave; của bạn lu&ocirc;n đẹp. Đặc biệt, cửa đi 2 c&aacute;nh nh&ocirc;m xingfa c&oacute; bảo vệ c&ograve;n được t&iacute;ch hợp t&iacute;nh năng an to&agrave;n chống trộm. Cửa đi 2 c&aacute;nh nh&ocirc;m xingfa được bố tr&iacute; c&aacute;c vị tr&iacute; như cửa ra ban c&ocirc;ng, cửa ph&ograve;ng, cửa nh&agrave; vệ sinh. Ch&uacute;ng được sản xuất từ loại nh&ocirc;m cao cấp Xingfa, với khả năng chịu lực cực tốt v&agrave; độ bền lớn.</p>\r\n<p class=\"text-center\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/posts/cua-di-2-canh-1.jpg\" /><br />C&aacute;c mẫu cửa nh&ocirc;m 2 c&aacute;nh</p>\r\n<p>Cửa nh&ocirc;m xingfa 2 c&aacute;nh được chia l&agrave;m 2 phần ch&iacute;nh:</p>\r\n<ul>\r\n<li>Bộ phận k&iacute;nh: l&agrave; loại k&iacute;nh cường lực (6 - 8mm). K&iacute;nh n&agrave;y sở hữu độ bền lớn.</li>\r\n<li>Bộ phận khung bao nh&ocirc;m: được nhập khẩu từ nước ngo&agrave;i. Độ d&agrave;y c&oacute; thể dao động từ 1.4 - 2mm.</li>\r\n</ul>\r\n<p>Hiện nay, mẫu cửa nh&ocirc;m xingfa 2 c&aacute;nh c&oacute; hai loại phổ biến tr&ecirc;n thị trường, bao gồm:</p>\r\n<ul>\r\n<li><strong>Cửa đi mở quay 2 c&aacute;nh nh&ocirc;m xingfa</strong>: c&oacute; g&oacute;c quay 90 độ, thuận tiện trong việc mở v&agrave; đ&oacute;ng cửa. Ch&uacute;ng mang đến những tiện &iacute;ch tối ưu, gi&uacute;p ng&ocirc;i nh&agrave; bạn th&ecirc;m phần phần khang trang, tiện dụng. T&ugrave;y theo nhu cầu sử dụng, kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn nhiều m&agrave;u sắc. Điển h&igrave;nh như m&agrave;u ghi, đen, trắng sứ hay m&agrave;u n&acirc;u trầm.</li>\r\n<li><strong>Cửa đi mở trượt 2 c&aacute;nh nh&ocirc;m xingfa</strong>: c&oacute; thiết kế trượt b&aacute;nh xe, gi&uacute;p thao t&aacute;c đ&oacute;ng cửa được nhẹ nh&agrave;ng. Thậm ch&iacute; l&agrave; kh&ocirc;ng g&acirc;y n&ecirc;n những tiếng ồn lớn, g&acirc;y cảm gi&aacute;c kh&oacute; chịu cho người sử dụng. Theo đ&oacute;, cửa c&oacute; thể mở rộng l&ecirc;n đến ⅔ to&agrave;n bộ diện t&iacute;ch cửa. Mẫu cửa nh&ocirc;m xingfa 2 c&aacute;nh đẹp loại n&agrave;y đặc biệt an to&agrave;n khi sử dụng, tr&aacute;nh được khả năng va đập mạnh. Nhất l&agrave; trong thời tiết xấu, mưa gi&oacute; b&atilde;o b&ugrave;ng hiện nay.</li>\r\n</ul>\r\n<h2>Th&ocirc;ng số kỹ thuật cửa đi 2 c&aacute;nh</h2>\r\n<p>Dưới đ&acirc;y l&agrave; k&iacute;ch thước chuẩn của cửa đi 2 c&aacute;nh bản lề 63 nh&ocirc;m xingfa hệ 55, c&ugrave;ng theo d&otilde;i ngay nh&eacute;!</p>\r\n<ul>\r\n<li>Chiều ngang: 1.4 (140cm) tối thiểu, 2.4 (240cm ) l&agrave; tối đa.</li>\r\n<li>Chiều cao: 2.2 (220cm) k&iacute;ch thước tối thiểu, 2m40 (240cm) k&iacute;ch thước tối đa chưa cộng lam cố định.</li>\r\n<li>Chiều cao &ocirc; cố định: 0.4m(40cm) tối thiểu, 0.6 ( 60cm ) chiều cao tối đa.</li>\r\n</ul>\r\n<p class=\"text-center\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"http://cuanhom-v2.nguyentrinhtravinh.com.vn/posts/cua-di-2-canh-2.jpg\" /><br />Cấu tạo cửa nh&ocirc;m 2 c&aacute;nh</p>\r\n<p><strong>Tr&ecirc;n đ&acirc;y, DTTN SX-TM Nguyễn Tr&igrave;nh vừa giới thiệu đến bạn đọc những th&ocirc;ng tin chi tiết về đặc điểm thiết kế, th&ocirc;ng số kỹ thuật, cũng như quy tr&igrave;nh ho&agrave;n thiện cửa đi 2 c&aacute;nh nh&ocirc;m Xingfa. Nếu quan t&acirc;m v&agrave; c&oacute; nhu cầu lắp đặt loại cửa n&agrave;y, li&ecirc;n hệ ngay với ch&uacute;ng t&ocirc;i qua số điện thoại 0294.384.0058. Rất mong hợp t&aacute;c với Qu&yacute; Kh&aacute;ch h&agrave;ng!</strong></p>', '2023-10-10 15:16:48', NULL, NULL, NULL, '2023-10-10 22:38:29', 1, '', '', 'PUBLISH', '', NULL, 0, 1),
(1901, '20231010-212809-Ir5V', 'http://localhost:9999/images/posts/20231010-212809-Ir5V/product-item6.png', 'he-cua-nhom;he-cua-so', 'sp 3', 'sp-3', 't', '<p>y</p>\r\n<p>y</p>', '2023-10-10 21:29:35', NULL, NULL, NULL, '2023-10-10 21:32:38', 1, '', '', 'PUBLISH', '', NULL, 0, 1),
(1903, '20231010-225241-BdKX', '', 'he-cua-nhom', 'f', 'f', '<p>fsd</p>', '', '2023-10-10 22:52:52', NULL, NULL, NULL, '2023-10-10 22:52:55', 1, '', '', 'PUBLISH', '', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `site`, `date_created`) VALUES
(1, 'nguyenvantyan@yahoo.com', 'localhost', '2022-09-13 05:26:14'),
(2, 'nguyenvantyan@gmail.com', 'localhost', '2022-09-13 05:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `news_catelogies`
--

DROP TABLE IF EXISTS `news_catelogies`;
CREATE TABLE IF NOT EXISTS `news_catelogies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_phoi_canh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_cua` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_thiet_ke` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news_catelogies`
--

INSERT INTO `news_catelogies` (`id`, `name`, `slug`, `pid`, `priority`, `level`, `summary`, `seo_title`, `seo_description`, `type`, `img_phoi_canh`, `img_cua`, `img_thiet_ke`) VALUES
(17, 'Tin tức', 'tin-tuc', 0, NULL, 1, NULL, '', '', 'POST', NULL, NULL, NULL),
(18, 'Báo giá', 'bao-gia', 0, NULL, 1, NULL, '', '', 'POST', NULL, NULL, NULL),
(19, 'Đại lý', 'dai-ly', 0, NULL, 1, NULL, '', '', 'POST', NULL, NULL, NULL),
(20, 'test', 'test', 17, 1, 2, NULL, '', '', 'POST', NULL, NULL, NULL),
(23, 'Hệ cửa nhôm', 'he-cua-nhom', 0, 1, 1, '<p>Cửa nh&ocirc;m k&iacute;nh kh&ocirc;ng chỉ bền, đẹp, th&iacute;ch hợp với sự thay đổi của điều kiện kh&iacute; hậu m&ocirc;i trường m&agrave; c&ograve;n c&oacute; t&iacute;nh chống nhiệt, chống nước, kh&ocirc;ng bị ảnh hưởng bởi mưa gi&oacute; như cửa nhựa hay bị bong tr&oacute;c khi thấm nước mưa như cửa gỗ.</p>', '', '', 'PRODUCT', 'http://localhost:9999/images/posts/_chung/product-new-2.png', 'http://localhost:9999/images/posts/_chung/product-item1.png', 'http://localhost:9999/images/posts/_chung/product-item-more1.png'),
(25, 'Hệ cửa đi', 'he-cua-di', 23, 1, 2, '', '', '', 'PRODUCT', NULL, NULL, NULL),
(26, 'Hệ cửa sổ', 'he-cua-so', 23, 2, 2, '', '', '', 'PRODUCT', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_by_day`
--

DROP TABLE IF EXISTS `pcounter_by_day`;
CREATE TABLE IF NOT EXISTS `pcounter_by_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_by_day`
--

INSERT INTO `pcounter_by_day` (`id`, `day`, `user`) VALUES
(5, '2020-04-04', 10),
(6, '2020-04-03', 15),
(7, '2020-04-02', 10),
(8, '2020-04-05', 1),
(9, '2020-04-07', 0),
(10, '2020-04-08', 1),
(11, '2020-04-09', 1),
(12, '2020-04-11', 0),
(13, '2020-04-12', 1),
(14, '2020-04-13', 1),
(15, '2020-04-14', 1),
(16, '2020-04-15', 1),
(17, '2020-05-11', 0),
(18, '2020-05-18', 0),
(19, '2020-06-07', 0),
(20, '2020-06-08', 1),
(21, '2020-06-24', 0),
(22, '2020-06-25', 1),
(23, '2020-07-08', 0),
(24, '2020-11-02', 0),
(25, '2020-11-03', 1),
(26, '2020-11-04', 1),
(27, '2020-11-05', 1),
(28, '2020-11-08', 0),
(29, '2021-02-24', 0),
(30, '2021-02-26', 0),
(31, '2021-03-08', 0),
(32, '2021-03-09', 1),
(33, '2021-03-10', 1),
(34, '2021-03-11', 1),
(35, '2021-06-03', 0),
(36, '2021-06-04', 1),
(37, '2021-06-05', 1),
(38, '2021-06-06', 1),
(39, '2021-07-11', 0),
(40, '2021-11-16', 0),
(41, '2021-11-18', 0),
(42, '2021-11-21', 0),
(43, '2021-11-22', 1),
(44, '2021-11-23', 1),
(45, '2021-11-24', 1),
(46, '2021-11-25', 1),
(47, '2021-12-01', 0),
(48, '2022-01-19', 0),
(49, '2022-02-07', 0),
(50, '2022-02-10', 0),
(51, '2022-02-11', 1),
(52, '2022-02-12', 1),
(53, '2022-02-13', 1),
(54, '2022-09-12', 0),
(55, '2022-09-17', 0),
(56, '2022-09-18', 1),
(57, '2022-09-23', 0),
(58, '2022-09-24', 1),
(59, '2022-09-25', 1),
(60, '2022-09-26', 1),
(61, '2022-09-27', 2),
(62, '2022-09-28', 1),
(63, '2022-09-30', 0),
(64, '2022-10-01', 1),
(65, '2022-10-04', 0),
(66, '2022-10-05', 1),
(67, '2022-10-06', 1),
(68, '2022-10-07', 1),
(69, '2022-10-09', 0),
(70, '2022-10-27', 0),
(71, '2022-12-18', 0),
(72, '2023-02-15', 0),
(73, '2023-10-05', 0),
(74, '2023-10-08', 0),
(75, '2023-10-09', 1),
(76, '2023-10-10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_save`
--

DROP TABLE IF EXISTS `pcounter_save`;
CREATE TABLE IF NOT EXISTS `pcounter_save` (
  `save_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `save_value` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`save_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_save`
--

INSERT INTO `pcounter_save` (`save_name`, `save_value`) VALUES
('counter', 18),
('day_time', 2460229),
('max_count', 126),
('max_time', 1585890000),
('yesterday', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_users`
--

DROP TABLE IF EXISTS `pcounter_users`;
CREATE TABLE IF NOT EXISTS `pcounter_users` (
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_time` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_users`
--

INSERT INTO `pcounter_users` (`user_ip`, `user_time`) VALUES
('837ec5754f503cfaaee0929fd48974e7', 1696990479);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE IF NOT EXISTS `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `id_parent` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_colors`
--

DROP TABLE IF EXISTS `product_colors`;
CREATE TABLE IF NOT EXISTS `product_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `color` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_colors`
--

INSERT INTO `product_colors` (`id`, `id_product`, `color`, `thumbnail`, `image`, `date_created`, `user_created`) VALUES
(2, 1900, 'GRAY', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-thumbnail-gray.png', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-gray.png', '2023-10-11 06:50:38', 1),
(3, 1900, 'WHITE', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-thumbnail-white.png', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-white.png', '2023-10-11 08:03:58', 1),
(4, 1900, 'WOOD', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-thumbnail-wood.png', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/cua-di-2-canh-wood.png', '2023-10-11 08:23:55', 1),
(5, 1901, 'GRAY', 'http://localhost:9999/images/posts/20231010-212809-Ir5V/product-item6.png', 'http://localhost:9999/images/posts/20231010-212809-Ir5V/product-item6.png', '2023-10-11 09:02:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE IF NOT EXISTS `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_product` (`id_product`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `id_product`, `thumbnail`, `image`, `date_created`, `user_created`) VALUES
(1, 1900, 'http://localhost:9999/images/posts/20231010-151634-Gz0I/product-thumbnail-2.jpg', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/product-large-2.jpg', '2023-10-11 08:52:12', 1),
(2, 1900, 'http://localhost:9999/images/posts/20231010-151634-Gz0I/product-item-more1.png', 'http://localhost:9999/images/posts/20231010-151634-Gz0I/product-item-more1.png', '2023-10-11 08:59:27', 1),
(3, 1901, 'http://localhost:9999/images/posts/20231010-212809-Ir5V/product-item6.png', 'http://localhost:9999/images/posts/20231010-212809-Ir5V/product-item6.png', '2023-10-11 09:03:14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site_copyright` text COLLATE utf8_unicode_ci NOT NULL,
  `text_homepage` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_description` text COLLATE utf8_unicode_ci,
  `site_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `site_phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `site_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `site_hotline` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `number_post_trending` tinyint(4) DEFAULT NULL,
  `number_post_catalog_home` tinyint(4) DEFAULT NULL,
  `number_post_per_page` tinyint(4) DEFAULT NULL,
  `number_post_like_in_news` tinyint(4) DEFAULT NULL,
  `number_post_in_menu` tinyint(4) DEFAULT NULL,
  `show_cover_after_summary` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_copyright`, `text_homepage`, `site_title`, `site_description`, `site_address`, `site_phone`, `site_email`, `site_hotline`, `number_post_trending`, `number_post_catalog_home`, `number_post_per_page`, `number_post_like_in_news`, `number_post_in_menu`, `show_cover_after_summary`) VALUES
(1, 'Cửa nhôm Nguyễn Trình Trà Vinh', '<p>Copyright &copy;  Website Nguyễn Trình<script>\r\n                            document.write(new Date().getFullYear());\r\n                            </script> All rights reserved\r\n                        </p>\r\n<p>\r\nCác thông tin trên trang web này chỉ mang tính chất tham khảo. Chúng tôi không chịu trách nhiệm nào do việc áp dụng các thông tin trên trang web này gây ra.\r\n</p>', 'Trang chủ 1', 'Website cửa nhôm', 'Website cửa nhôm', 'Đường Nguyễn Đáng, khóm 10, P9, TP Trà Vinh, Tỉnh Trà Vinh', '0294.384.0058 - 090 379 4531', 'nguyentrinh40@yahoo.com', '02943840058', 4, 5, 9, 5, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
CREATE TABLE IF NOT EXISTS `socials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `name`, `icon`, `link`, `priority`) VALUES
(1, 'Facebook', '<span class=\"icon-facebook\"></span>', 'facebook.com', 2),
(2, 'Twitter', '<span class=\"icon-twitter\"></span>', 'twitter.com', 1),
(3, 'Instagram', '<span class=\"icon-instagram\"></span>', 'instagram.com', 1),
(4, 'Youtube', '<span class=\"icon-youtube-play\"></span>', 'youtube.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tag_list`
--

DROP TABLE IF EXISTS `tag_list`;
CREATE TABLE IF NOT EXISTS `tag_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tag_list`
--

INSERT INTO `tag_list` (`id`, `name`, `slug`, `date_created`, `seo_title`, `seo_description`) VALUES
(187, 'nhôm Xingfa', 'nhom-xingfa', '2023-10-06 20:17:21', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(1) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `id_phong` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`, `name`, `phone`, `address`, `id_phong`) VALUES
(1, 'superadmin@gmail.com', 'kz2px152FAWlkHbkZoCiXgBAd-S8SSjF', '$2y$13$DSISRUJSkr4CPeb3Ciwl1u3ubaGF50gXzzgTaDmpi5ph2Hie8JL9q', NULL, 1, 1, 1426062188, 1586049758, NULL, '', 'superadmin@gmail.com', 1, 'Mr. Admin 1', '374711908', 'Càng Long - Trà Vinh 1', 1),
(6, 'haile', 'P-4dKQtD2HD7BvJMaqLQ-H8wM01MgTCB', '$2y$13$FtZls2EP6u/YH8Tq3gNpbehYn.0bfhDzOzl8w9LZnv1U3iy67tDKy', NULL, 1, 0, 1664291079, 1664291079, '127.0.0.1', '', '', 0, 'Hải Lê', '01234', 'Trà Vinh', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `language` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '594b942a08db7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498125354, 'Chrome', 'Windows'),
(2, '594e6c6038079', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498311776, 'Chrome', 'Windows'),
(3, '594f4139aedb5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498366265, 'Chrome', 'Windows'),
(4, '595ef7d44d1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 1, 1499396052, 'Chrome', 'Windows'),
(5, '59e8a6d8a9558', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508419288, 'Chrome', 'Windows'),
(6, '59ee962cb327d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508808236, 'Chrome', 'Windows'),
(7, '59ef5ebdeec13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508859581, 'Chrome', 'Windows'),
(8, '59ef6a5ad7e55', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508862554, 'Chrome', 'Windows'),
(9, '59ef70a2e9811', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508864162, 'Chrome', 'Windows'),
(10, '59f0b2e7171a8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508946663, 'Chrome', 'Windows'),
(11, '59f0cd9d161a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508953501, 'Chrome', 'Windows'),
(12, '59f1304f26745', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508978767, 'Chrome', 'Windows'),
(13, '59f1456cbea96', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508984172, 'Chrome', 'Windows'),
(14, '59f1807420d18', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508999284, 'Chrome', 'Windows'),
(15, '59f29d6be7ea5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509072235, 'Chrome', 'Windows'),
(16, '59f2e74688480', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509091142, 'Chrome', 'Windows'),
(17, '59f3d7d1bcc8f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509152721, 'Chrome', 'Windows'),
(18, '59f688a11dd11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509329057, 'Chrome', 'Windows'),
(19, '59f6c6b702579', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509344951, 'Chrome', 'Windows'),
(20, '59f747ceb4e37', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509377998, 'Chrome', 'Windows'),
(21, '59f992dfa3650', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509528287, 'Chrome', 'Windows'),
(22, '59f9e7bbac6f9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509550011, 'Chrome', 'Windows'),
(23, '59fff730e5ab3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509947184, 'Chrome', 'Windows'),
(24, '5a005c828502a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509973122, 'Chrome', 'Windows'),
(25, '5a00833f42ef8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509983039, 'Chrome', 'Windows'),
(26, '5a008bd985854', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509985241, 'Chrome', 'Windows'),
(27, '5a032315d55e7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510155029, 'Chrome', 'Windows'),
(28, '5a09a9c638959', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510582726, 'Chrome', 'Windows'),
(29, '5a0bcc8d46ae1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510722701, 'Chrome', 'Windows'),
(30, '5a0c507c1bbc0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510756476, 'Chrome', 'Windows'),
(31, '5a158ee83c3a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511362280, 'Chrome', 'Windows'),
(32, '5a16e76aac9a0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511450474, 'Chrome', 'Windows'),
(33, '5a1c03e4e7758', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511785444, 'Chrome', 'Windows'),
(34, '5a1c2a002fa8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511795200, 'Chrome', 'Windows'),
(35, '5a1d8a8b23e08', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511885451, 'Chrome', 'Windows'),
(36, '5a202b327efa1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512057650, 'Chrome', 'Windows'),
(37, '5a24d16ba2ee7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512362347, 'Chrome', 'Windows'),
(38, '5a256932f0cc3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512401202, 'Chrome', 'Windows'),
(39, '5a26c795b5a20', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512490901, 'Chrome', 'Windows'),
(40, '5a2ab2d0d270e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512747728, 'Chrome', 'Windows'),
(41, '5a2e1341e8e0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512969025, 'Chrome', 'Windows'),
(42, '5a329a097ad3f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513265673, 'Chrome', 'Windows'),
(43, '5a33e86702cf4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513351271, 'Chrome', 'Windows'),
(44, '5b8566d214a65', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535469266, 'Chrome', 'Windows'),
(45, '5b878bb8d24fd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535609784, 'Chrome', 'Windows'),
(46, '5b880eecbba11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535643372, 'Chrome', 'Windows'),
(47, '5b8c87273a4fc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535936295, 'Chrome', 'Windows'),
(48, '5b8d23079177c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535976199, 'Chrome', 'Windows'),
(49, '5b8ddf31af79a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536024369, 'Chrome', 'Windows'),
(50, '5b8e819351601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536065939, 'Chrome', 'Windows'),
(51, '5b8e9d9d98f1c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536073117, 'Chrome', 'Windows'),
(52, '5b8ea8323c5b1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536075826, 'Chrome', 'Windows'),
(53, '5b8ea9e478538', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536076260, 'Chrome', 'Windows'),
(54, '5b8f277b1677c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536108411, 'Chrome', 'Windows'),
(55, '5b8f76b89e150', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536128696, 'Chrome', 'Windows'),
(56, '5b908f32ac6d8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536200498, 'Chrome', 'Windows'),
(57, '5b9a80b80c904', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536852152, 'Chrome', 'Windows'),
(58, '5b9a812bb36a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536852267, 'Chrome', 'Windows'),
(59, '5b9a860f21927', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853519, 'Chrome', 'Windows'),
(60, '5b9a876886dcd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853864, 'Chrome', 'Windows'),
(61, '5b9a881b4ba36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854043, 'Chrome', 'Windows'),
(62, '5b9a89a9e4cc1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854441, 'Chrome', 'Windows'),
(63, '5b9bbc7979e36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536932985, 'Chrome', 'Windows'),
(64, '5b9e6fa2dcd51', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537109922, 'Chrome', 'Windows'),
(65, '5ba1eeb6c9155', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537339062, 'Chrome', 'Windows'),
(66, '5ba7187e1e6ea', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36 Avast/69.0.792.81', 1, 1537677438, 'Chrome', 'Windows'),
(67, '5ba7195ab7712', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537677658, 'Chrome', 'Windows'),
(68, '5ba8816455e8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537769828, 'Chrome', 'Windows'),
(69, '5baa542ec53a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537889326, 'Chrome', 'Windows'),
(70, '5baa55d7d6912', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0', 1, 1537889751, 'Firefox', 'Windows'),
(71, '5bac244e659d1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538008142, 'Chrome', 'Windows'),
(72, '5bb1734b8dffa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538356043, 'Chrome', 'Windows'),
(73, '5bb433d544aad', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538536405, 'Chrome', 'Windows'),
(74, '5c2037ee33982', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 1, 1545615342, 'Chrome', 'Windows'),
(75, '5ca93b363c1d5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1, 1554594614, 'Chrome', 'Windows'),
(76, '5cb881f5a13b5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555595765, 'Chrome', 'Windows'),
(77, '5cb8a07a1a58a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555603578, 'Chrome', 'Windows'),
(78, '5cb8a3345894c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604276, 'Chrome', 'Windows'),
(79, '5cb8a46ceb412', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604588, 'Chrome', 'Windows'),
(80, '5cb8a4db8e4e6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604699, 'Chrome', 'Windows'),
(81, '5cb8a81ce9027', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555605532, 'Chrome', 'Windows'),
(82, '5cb8ad0e4d571', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606798, 'Chrome', 'Windows'),
(83, '5cb8ad3a61129', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606842, 'Chrome', 'Windows'),
(84, '5cb9245bd697b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555637339, 'Chrome', 'Windows'),
(85, '5cb94239a8a3c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555644985, 'Chrome', 'Windows'),
(86, '5cb9431be7c4e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555645211, 'Chrome', 'Windows'),
(87, '5cb943c69bec8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555645382, 'Chrome', 'Windows'),
(88, '5cb9f703675a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555691267, 'Chrome', 'Windows'),
(89, '5cba88e7ab1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555728615, 'Chrome', 'Windows'),
(90, '5cbb34767942f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555772534, 'Chrome', 'Windows'),
(91, '5cc11ae1685bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556159201, 'Chrome', 'Windows'),
(92, '5cc2b15586208', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556263253, 'Chrome', 'Windows'),
(93, '5cc3f0f405d84', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556345076, 'Chrome', 'Windows'),
(94, '5cc84741d0fbb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556629313, 'Chrome', 'Windows'),
(95, '5d4974633a124', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', 1, 1565095011, 'Chrome', 'Windows'),
(96, '5d4e27b421051', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565403060, 'Chrome', 'Windows'),
(97, '5d50b845dd0c4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565571141, 'Chrome', 'Windows'),
(98, '5d538429662db', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754409, 'Chrome', 'Windows'),
(99, '5d53854e94bdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754702, 'Chrome', 'Windows'),
(100, '5d5388a9aed8b', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565755561, 'Chrome', 'Windows'),
(101, '5d53abcf46651', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565764559, 'Chrome', 'Windows'),
(102, '5d779315820f5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568117525, 'Chrome', 'Windows'),
(103, '5d78a4f3c95dd', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568187635, 'Chrome', 'Windows'),
(104, '5d95b078d3259', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570091128, 'Chrome', 'Windows'),
(105, '5d96268fc2554', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570121359, 'Chrome', 'Windows'),
(106, '5d96269ed67ee', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', NULL, 1570121374, 'Chrome', 'Windows'),
(107, '5d96f34b0fc1e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570173771, 'Chrome', 'Windows'),
(108, '5d989cad3a601', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570282669, 'Chrome', 'Windows'),
(109, '5da82e7283d94', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571303026, 'Chrome', 'Windows'),
(110, '5da97c8d06f4e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571388557, 'Chrome', 'Windows'),
(111, '5dafaddb87cd8', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571794395, 'Chrome', 'Windows'),
(112, '5dbe1b954efdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1572739989, 'Chrome', 'Windows'),
(113, '5e4debc821c02', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582164936, 'Chrome', 'Windows'),
(114, '5e549263d8fb4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582600803, 'Chrome', 'Windows'),
(115, '5e5dad753e106', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583197557, 'Chrome', 'Windows'),
(116, '5e5f53a1b905f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583305633, 'Chrome', 'Windows'),
(117, '5e60722a6bedf', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583378986, 'Chrome', 'Windows'),
(118, '5e6116f3a4287', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583421171, 'Chrome', 'Windows'),
(119, '5e61f1a59e18a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583477157, 'Chrome', 'Windows'),
(120, '5e6607738f7eb', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583744883, 'Chrome', 'Windows'),
(121, '5e6659e348e5d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583765987, 'Chrome', 'Windows'),
(122, '5e674a99468e5', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583827609, 'Chrome', 'Windows'),
(123, '5e686bcb64f52', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583901643, 'Chrome', 'Windows'),
(124, '5e698721e44b9', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583974177, 'Chrome', 'Windows'),
(125, '5e69a03b878af', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583980603, 'Chrome', 'Windows'),
(126, '5e6ad745790df', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584060229, 'Chrome', 'Windows'),
(127, '5e6afa6675f2c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584069222, 'Chrome', 'Windows'),
(128, '5e6ecce078976', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584319712, 'Chrome', 'Windows'),
(129, '5e71c528c782c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584514344, 'Chrome', 'Windows'),
(130, '5e71c56635718', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584514406, 'Chrome', 'Windows'),
(131, '5e71c820cbd73', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584515104, 'Chrome', 'Windows'),
(132, '5e71d255f30c1', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584517717, 'Chrome', 'Windows'),
(133, '5e72c6a32ed18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584580259, 'Chrome', 'Windows'),
(134, '5e742c60879d0', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584671840, 'Chrome', 'Windows'),
(135, '5e78118d82a5c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584927117, 'Chrome', 'Windows'),
(136, '5e78667e3345d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584948862, 'Chrome', 'Windows'),
(137, '5e795d15dc80c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585011989, 'Chrome', 'Windows'),
(138, '5e7d6b5f90456', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585277791, 'Chrome', 'Windows'),
(139, '5e81a6f53943d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585555189, 'Chrome', 'Windows'),
(140, '5e829a6cdb25e', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585617516, 'Chrome', 'Windows'),
(141, '5e8448e4e9c92', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585727716, 'Chrome', 'Windows'),
(142, '5e848206686ae', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585742342, 'Chrome', 'Windows'),
(143, '5e86b5b0e7d81', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585886640, 'Chrome', 'Windows'),
(144, '5e86f3cc5e02c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585902540, 'Chrome', 'Windows'),
(145, '5e87060000c41', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585907200, 'Chrome', 'Windows'),
(146, '5e88323f677a6', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585984063, 'Chrome', 'Windows'),
(147, '5e8836c203a18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585985218, 'Chrome', 'Windows'),
(148, '5e884af3b7e61', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585990387, 'Chrome', 'Windows'),
(149, '5e88600ddd2db', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1585995789, 'Chrome', 'Windows'),
(150, '5e892beb48615', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586047979, 'Chrome', 'Windows'),
(151, '5e8932ae84461', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049710, 'Chrome', 'Windows'),
(152, '5e89331dd420c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049821, 'Chrome', 'Windows'),
(153, '5e8939720c509', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586051442, 'Chrome', 'Windows'),
(154, '5e89c3f053845', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586086896, 'Chrome', 'Windows'),
(155, '5e8d3f40373d6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586315072, 'Chrome', 'Windows'),
(156, '5e8d3f6a1189d', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586315114, 'Chrome', 'Windows'),
(157, '5e9080ca1b2ca', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586528458, 'Chrome', 'Windows'),
(158, '5e9256944d3d3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586648724, 'Chrome', 'Windows'),
(159, '5e957a1cdb486', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586854428, 'Chrome', 'Windows'),
(160, '5e97bffb6e420', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1587003387, 'Chrome', 'Windows'),
(161, '5eba4bcdba14c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36', 1, 1589267405, 'Chrome', 'Windows'),
(162, '5edd850fb15a0', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591575823, 'Chrome', 'Windows'),
(163, '5edd868884ab7', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591576200, 'Chrome', 'Windows'),
(164, '5edda481d9e66', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591583873, 'Chrome', 'Windows'),
(165, '5edee38066441', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591665536, 'Chrome', 'Windows'),
(166, '5edee3c6c76b1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665606, 'Chrome', 'Windows'),
(167, '5edee506e4fec', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665926, 'Chrome', 'Windows'),
(168, '5ef4c54e40700', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593099598, 'Chrome', 'Windows'),
(169, '5ef550a2613b5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593135266, 'Chrome', 'Windows'),
(170, '5f067152e1d34', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1594257746, 'Chrome', 'Windows'),
(171, '5f06719fc5bb6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', NULL, 1594257823, 'Chrome', 'Windows'),
(172, '5fa257308e037', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604474672, 'Chrome', 'Windows'),
(173, '5fa4b80680060', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604630534, 'Chrome', 'Windows'),
(174, '60372d29b9962', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', 1, 1614228777, 'Chrome', 'Windows'),
(175, '60372d6f5b7d8', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', NULL, 1614228847, 'Chrome', 'Windows'),
(176, '6046e9137ab3f', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615259923, 'Chrome', 'Windows'),
(177, '604819f5303f1', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615337973, 'Chrome', 'Windows'),
(178, '6049d8e5dd6b4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615452389, 'Chrome', 'Windows'),
(179, '6049dbfee39a9', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', NULL, 1615453182, 'Chrome', 'Windows'),
(180, '604ac159e6b22', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615511897, 'Chrome', 'Windows'),
(181, '60b9e1083005c', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622794504, 'Chrome', 'Windows'),
(182, '60bae34d258f6', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622860621, 'Chrome', 'Windows'),
(183, '60bae52d0535a', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622861101, 'Chrome', 'Windows'),
(184, '60bd8da9800d5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1623035305, 'Chrome', 'Windows'),
(185, '60eba51ba1bb3', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 1, 1626055963, 'Chrome', 'Windows'),
(186, '60eba6ba36295', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056378, 'Chrome', 'Windows'),
(187, '60eba751bbf8b', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056529, 'Chrome', 'Windows'),
(188, '60eba7aa864ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056618, 'Chrome', 'Windows'),
(189, '60eba8330509e', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056755, 'Chrome', 'Windows'),
(190, '60eba8ccdb5ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056908, 'Chrome', 'Windows'),
(191, '6194ce72de6c5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637142130, 'Chrome', 'Windows'),
(192, '619746aa90c09', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637303978, 'Chrome', 'Windows'),
(193, '619751d50efb4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637306837, 'Chrome', 'Windows'),
(194, '619ae916a5efa', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637542166, 'Chrome', 'Windows'),
(195, '619d151c20277', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637684508, 'Chrome', 'Windows'),
(196, '619e714974085', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637773641, 'Chrome', 'Windows'),
(197, '619f3511248ca', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637823761, 'Chrome', 'Windows'),
(198, '61a03438d06ce', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637889080, 'Chrome', 'Windows'),
(199, '61e8db9c551ae', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 1, 1642650524, 'Chrome', 'Windows'),
(200, '62067ec846026', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36', 1, 1644592840, 'Chrome', 'Windows'),
(201, '6320160e8ed28', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663047182, 'Chrome', 'Windows'),
(202, '6326dc416dd21', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663491137, 'Chrome', 'Windows'),
(203, '632eb85c535fa', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664006236, 'Chrome', 'Windows'),
(204, '632fe04cd5313', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664081996, 'Chrome', 'Windows'),
(205, '63331bf466694', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 6, 1664293876, 'Chrome', 'Windows'),
(206, '63331cd3edcd6', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 6, 1664294099, 'Chrome', 'Windows'),
(207, '63342574185ac', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664361844, 'Chrome', 'Windows'),
(208, '63382ff1e92e5', '14.191.61.205', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664626673, 'Chrome', 'Windows'),
(209, '633cefca2fdcc', '123.23.13.149', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664937930, 'Chrome', 'Windows'),
(210, '633fd7b3d7141', '118.68.56.13', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1665128371, 'Chrome', 'Windows'),
(211, '635b6b16f0db1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1666935574, 'Chrome', 'Windows'),
(212, '63a06823b2435', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1671456803, 'Chrome', 'Windows'),
(213, '63ee404a622f1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676558410, 'Chrome', 'Windows'),
(214, '651f7fe27e7d5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696563170, 'Chrome', 'Windows'),
(215, '651f801ab94b1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696563226, 'Chrome', 'Windows'),
(216, '651fc93e7b0bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581950, 'Chrome', 'Windows'),
(217, '651fd713c3707', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696585491, 'Chrome', 'Windows'),
(218, '652006d62393b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696597718, 'Chrome', 'Windows'),
(219, '65202b7230be0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696607090, 'Chrome', 'Windows'),
(220, '65235ada1f788', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696815834, 'Chrome', 'Windows');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
